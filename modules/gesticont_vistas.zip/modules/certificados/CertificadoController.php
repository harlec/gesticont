<?php
require_once ROOT . '/core/Auth.php';
require_once ROOT . '/core/Model.php';
require_once ROOT . '/services/EncryptService.php';
class CertificadoController {
    public function index(int $empresaId): void {
        Auth::require();
        $empModel = new class extends Model { protected string $table = 'empresas'; };
        $empresa = $empModel->findById($empresaId);
        if (!$empresa) { http_response_code(404); die('Empresa no encontrada'); }
        $certModel = new class extends Model { protected string $table = 'empresa_certificados'; };
        $cert = $certModel->findOne(['empresa_id' => $empresaId, 'estado' => 'activo']);
        $pageTitle = 'Certificado — ' . $empresa['razon_social'];
        ob_start();
        require_once ROOT . '/modules/certificados/views/index.php';
        $content = ob_get_clean();
        require_once ROOT . '/views/layout/base.php';
    }
    public function subir(int $empresaId): void {
        Auth::require();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header("Location: /empresas/{$empresaId}/certificado"); exit; }
        $encrypt = new EncryptService();
        $certModel = new class extends Model { protected string $table = 'empresa_certificados'; };
        $certModel->execute("UPDATE empresa_certificados SET estado = 'revocado' WHERE empresa_id = ? AND estado = 'activo'", [$empresaId]);
        $certModel->insert([
            'empresa_id'     => $empresaId,
            'cert_path'      => '',
            'cert_password'  => $encrypt->encrypt($_POST['cert_password'] ?? 'sin_cert'),
            'sol_usuario'    => $encrypt->encrypt($_POST['sol_usuario'] ?? ''),
            'sol_clave'      => $encrypt->encrypt($_POST['sol_clave'] ?? ''),
            'ambiente'       => $_POST['ambiente'] ?? 'beta',
            'estado'         => 'activo',
            'configurado_por'=> Auth::id(),
        ]);
        header("Location: /empresas/{$empresaId}");
        exit;
    }
}
