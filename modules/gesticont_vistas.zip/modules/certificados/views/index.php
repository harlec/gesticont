<?php
$regimenes = ['general'=>'Régimen General','mype'=>'MYPE Tributario','especial'=>'Régimen Especial','rus'=>'Nuevo RUS'];
?>
<div style="max-width:640px;">
    <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:16px 20px;margin-bottom:24px;font-size:13px;color:#1e3a8a;line-height:1.6;">
        <strong>¿Qué necesitas?</strong> Las credenciales SOL (usuario y clave) del portal SUNAT de esta empresa. Se guardan encriptadas con AES-256 y solo se usan para sincronizar ventas y compras automáticamente.
    </div>

    <?php if ($cert): ?>
    <div style="background:#dcfce7;border:1px solid #bbf7d0;border-radius:12px;padding:16px 20px;margin-bottom:24px;">
        <div style="font-weight:700;color:#166534;font-size:14px;margin-bottom:8px;">✓ Credenciales configuradas</div>
        <div style="font-size:13px;color:#166534;">Ambiente: <strong><?= ucfirst($cert['ambiente']) ?></strong></div>
        <?php if ($cert['cert_hasta']): ?>
        <div style="font-size:13px;color:#166534;margin-top:4px;">Certificado vence: <strong><?= date('d/m/Y', strtotime($cert['cert_hasta'])) ?></strong></div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div style="background:white;border-radius:12px;border:1px solid #e2e8f0;overflow:hidden;">
        <div style="padding:20px 24px;border-bottom:1px solid #e2e8f0;background:#f8fafc;">
            <div style="font-weight:700;font-size:16px;color:#1e293b;">🔐 <?= $cert ? 'Actualizar credenciales' : 'Configurar credenciales' ?></div>
            <div style="font-size:13px;color:#475569;margin-top:4px;"><?= htmlspecialchars($empresa['razon_social']) ?> · RUC: <?= $empresa['ruc'] ?></div>
        </div>
        <form method="POST" action="/empresas/<?= $empresa['id'] ?>/certificado">
            <div style="padding:24px;display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Usuario SOL *</label>
                    <input type="text" name="sol_usuario" required placeholder="USUARIO_SOL" style="width:100%;padding:10px 14px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;outline:none;font-family:monospace;" onfocus="this.style.borderColor='#1e3a8a'" onblur="this.style.borderColor='#e2e8f0'"/>
                    <div style="font-size:11px;color:#94a3b8;margin-top:4px;">Solo el usuario, no incluir el RUC</div>
                </div>
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Clave SOL *</label>
                    <input type="password" name="sol_clave" required placeholder="••••••••" style="width:100%;padding:10px 14px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;outline:none;font-family:inherit;" onfocus="this.style.borderColor='#1e3a8a'" onblur="this.style.borderColor='#e2e8f0'"/>
                </div>
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Contraseña certificado .pfx</label>
                    <input type="password" name="cert_password" placeholder="Solo si tiene certificado .pfx" style="width:100%;padding:10px 14px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;outline:none;font-family:inherit;" onfocus="this.style.borderColor='#1e3a8a'" onblur="this.style.borderColor='#e2e8f0'"/>
                </div>
                <div>
                    <label style="display:block;font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Ambiente SUNAT *</label>
                    <select name="ambiente" style="width:100%;padding:10px 14px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;outline:none;font-family:inherit;background:white;">
                        <option value="beta">Beta (pruebas)</option>
                        <option value="produccion">Producción</option>
                    </select>
                </div>
            </div>
            <div style="padding:16px 24px;border-top:1px solid #e2e8f0;background:#f8fafc;display:flex;justify-content:flex-end;gap:12px;">
                <a href="/empresas/<?= $empresa['id'] ?>" style="background:#f1f5f9;color:#475569;padding:10px 20px;border-radius:8px;font-size:14px;font-weight:600;text-decoration:none;">Cancelar</a>
                <button type="submit" style="background:#1e3a8a;color:white;padding:10px 24px;border-radius:8px;font-size:14px;font-weight:600;border:none;cursor:pointer;font-family:inherit;">Guardar y encriptar</button>
            </div>
        </form>
    </div>
</div>
