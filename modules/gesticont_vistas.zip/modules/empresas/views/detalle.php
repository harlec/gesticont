<?php
try {
    $db = Model::db();
    $cert = $db->query("SELECT * FROM empresa_certificados WHERE empresa_id = ? AND estado = 'activo' LIMIT 1", [$empresa['id']])[0] ?? null;
    $resumen = $db->query("SELECT * FROM resumen_mensual WHERE empresa_id = ? ORDER BY periodo DESC LIMIT 6", [$empresa['id']]);
    $ultimasVentas = $db->query("SELECT COUNT(*) as cant, SUM(total) as total FROM registro_ventas WHERE empresa_id = ? AND DATE_FORMAT(fecha_emision,'%Y%m') = DATE_FORMAT(CURDATE(),'%Y%m')", [$empresa['id']])[0] ?? null;
    $ultimasCompras = $db->query("SELECT COUNT(*) as cant, SUM(total) as total FROM registro_compras WHERE empresa_id = ? AND DATE_FORMAT(fecha_emision,'%Y%m') = DATE_FORMAT(CURDATE(),'%Y%m')", [$empresa['id']])[0] ?? null;
} catch (Exception $ex) {
    $cert = null; $resumen = []; $ultimasVentas = null; $ultimasCompras = null;
}
$regimenes = ['general'=>'Régimen General','mype'=>'MYPE Tributario','especial'=>'Régimen Especial','rus'=>'Nuevo RUS'];
?>
<div style="display:flex;align-items:center;gap:16px;margin-bottom:24px;">
    <div style="width:52px;height:52px;background:#1e3a8a;border-radius:12px;display:flex;align-items:center;justify-content:center;font-family:Georgia,serif;font-size:22px;font-weight:700;color:white;flex-shrink:0;">
        <?= strtoupper(substr($empresa['razon_social'],0,1)) ?>
    </div>
    <div style="flex:1;">
        <div style="font-size:20px;font-weight:700;color:#1e293b;"><?= htmlspecialchars($empresa['razon_social']) ?></div>
        <div style="font-size:13px;color:#94a3b8;margin-top:2px;">RUC: <?= $empresa['ruc'] ?> · <?= $regimenes[$empresa['regimen']] ?? '' ?></div>
    </div>
    <div style="display:flex;gap:10px;">
        <a href="/empresas/<?= $empresa['id'] ?>/editar" style="background:#f1f5f9;color:#475569;padding:8px 16px;border-radius:8px;font-size:13px;font-weight:600;text-decoration:none;">Editar</a>
        <a href="/empresas/<?= $empresa['id'] ?>/certificado" style="background:#fef3c7;color:#92400e;padding:8px 16px;border-radius:8px;font-size:13px;font-weight:600;text-decoration:none;">Certificado</a>
    </div>
</div>

<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:24px;">
    <div style="background:white;border-radius:12px;padding:18px;border:1px solid #e2e8f0;">
        <div style="font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Ventas este mes</div>
        <div style="font-size:26px;font-weight:700;color:#1e3a8a;">S/ <?= number_format($ultimasVentas['total'] ?? 0, 2) ?></div>
        <div style="font-size:12px;color:#94a3b8;margin-top:4px;"><?= $ultimasVentas['cant'] ?? 0 ?> comprobantes</div>
    </div>
    <div style="background:white;border-radius:12px;padding:18px;border:1px solid #e2e8f0;">
        <div style="font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Compras este mes</div>
        <div style="font-size:26px;font-weight:700;color:#1e293b;">S/ <?= number_format($ultimasCompras['total'] ?? 0, 2) ?></div>
        <div style="font-size:12px;color:#94a3b8;margin-top:4px;"><?= $ultimasCompras['cant'] ?? 0 ?> facturas</div>
    </div>
    <div style="background:white;border-radius:12px;padding:18px;border:1px solid #e2e8f0;">
        <div style="font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Certificado digital</div>
        <?php if ($cert): ?>
        <div style="font-size:14px;font-weight:700;color:#166534;">✓ Activo</div>
        <div style="font-size:12px;color:#94a3b8;margin-top:4px;">Vence: <?= date('d/m/Y', strtotime($cert['cert_hasta'])) ?></div>
        <?php else: ?>
        <div style="font-size:14px;font-weight:700;color:#92400e;">⚠ Sin certificado</div>
        <a href="/empresas/<?= $empresa['id'] ?>/certificado" style="font-size:12px;color:#2563eb;text-decoration:none;margin-top:4px;display:block;">Configurar →</a>
        <?php endif; ?>
    </div>
</div>

<?php if (!empty($resumen)): ?>
<div style="background:white;border-radius:12px;border:1px solid #e2e8f0;overflow:hidden;">
    <div style="padding:16px 20px;border-bottom:1px solid #e2e8f0;font-weight:700;font-size:15px;color:#1e293b;">Historial mensual</div>
    <table style="width:100%;border-collapse:collapse;">
        <thead>
            <tr style="background:#f8fafc;">
                <th style="padding:10px 20px;text-align:left;font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;">Período</th>
                <th style="padding:10px 20px;text-align:right;font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;">Ventas</th>
                <th style="padding:10px 20px;text-align:right;font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;">Compras</th>
                <th style="padding:10px 20px;text-align:right;font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;">IGV a pagar</th>
                <th style="padding:10px 20px;text-align:right;font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;">Renta</th>
                <th style="padding:10px 20px;text-align:center;font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;">Estado</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($resumen as $r): ?>
            <?php $estados = ['generado'=>['#eff6ff','#1e3a8a','Generado'],'pendiente_revision'=>['#fef3c7','#92400e','Pendiente'],'revisado'=>['#dcfce7','#166534','Revisado'],'declarado'=>['#dcfce7','#166534','Declarado']]; $est = $estados[$r['estado']] ?? ['#f1f5f9','#64748b','—']; ?>
            <tr style="border-top:1px solid #f1f5f9;">
                <td style="padding:12px 20px;font-size:14px;font-weight:600;color:#1e293b;"><?= substr($r['periodo'],0,4) . '/' . substr($r['periodo'],4,2) ?></td>
                <td style="padding:12px 20px;text-align:right;font-size:14px;color:#1e293b;">S/ <?= number_format($r['base_ventas'],2) ?></td>
                <td style="padding:12px 20px;text-align:right;font-size:14px;color:#1e293b;">S/ <?= number_format($r['base_compras'],2) ?></td>
                <td style="padding:12px 20px;text-align:right;font-size:14px;font-weight:600;color:<?= $r['igv_a_pagar'] > 0 ? '#991b1b' : '#166534' ?>;">S/ <?= number_format($r['igv_a_pagar'],2) ?></td>
                <td style="padding:12px 20px;text-align:right;font-size:14px;color:#1e293b;">S/ <?= number_format($r['renta_a_pagar'],2) ?></td>
                <td style="padding:12px 20px;text-align:center;"><span style="background:<?= $est[0] ?>;color:<?= $est[1] ?>;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:700;"><?= $est[2] ?></span></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php else: ?>
<div style="background:white;border-radius:12px;border:1px solid #e2e8f0;padding:40px;text-align:center;color:#94a3b8;font-size:14px;">
    Sin datos mensuales aún. Se generarán automáticamente cuando corran los crons.
</div>
<?php endif; ?>
